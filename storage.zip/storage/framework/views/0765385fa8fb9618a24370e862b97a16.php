

<?php $__env->startSection('title', 'Data Laporan'); ?>

<?php $__env->startSection('content'); ?>

<div class="w-full min-h-screen bg-[#F5F7FA] pb-10">

    
    <div class="mb-10">

        <div class="flex flex-col lg:flex-row
                    lg:items-center
                    lg:justify-between gap-6">

            <div>

                <h1 class="text-5xl font-black text-[#1E293B]">

                    Data Laporan

                </h1>

                <p class="mt-3 text-lg text-gray-500">

                    Ringkasan statistik pertumbuhan anak,
                    status gizi, dan perkembangan stunting.

                </p>

            </div>

        </div>

    </div>

    
    <div class="mb-8 flex flex-wrap items-center gap-4">

        
        <select
            id="filter-bulan"
            class="bg-white
                   border border-[#DCE6F2]
                   rounded-2xl
                   px-5 py-3
                   text-gray-700
                   focus:outline-none"
        >

            <option value="">
                Semua Bulan
            </option>

            <option value="1" <?php echo e(request('bulan') == '1' ? 'selected' : ''); ?>>
                Januari
            </option>

            <option value="2" <?php echo e(request('bulan') == '2' ? 'selected' : ''); ?>>
                Februari
            </option>

            <option value="3" <?php echo e(request('bulan') == '3' ? 'selected' : ''); ?>>
                Maret
            </option>

            <option value="4" <?php echo e(request('bulan') == '4' ? 'selected' : ''); ?>>
                April
            </option>

            <option value="5" <?php echo e(request('bulan') == '5' ? 'selected' : ''); ?>>
                Mei
            </option>

            <option value="6" <?php echo e(request('bulan') == '6' ? 'selected' : ''); ?>>
                Juni
            </option>

            <option value="7" <?php echo e(request('bulan') == '7' ? 'selected' : ''); ?>>
                Juli
            </option>

            <option value="8" <?php echo e(request('bulan') == '8' ? 'selected' : ''); ?>>
                Agustus
            </option>

            <option value="9" <?php echo e(request('bulan') == '9' ? 'selected' : ''); ?>>
                September
            </option>

            <option value="10" <?php echo e(request('bulan') == '10' ? 'selected' : ''); ?>>
                Oktober
            </option>

            <option value="11" <?php echo e(request('bulan') == '11' ? 'selected' : ''); ?>>
                November
            </option>

            <option value="12" <?php echo e(request('bulan') == '12' ? 'selected' : ''); ?>>
                Desember
            </option>

        </select>

        
        <select
            id="filter-tahun"
            class="bg-white
                   border border-[#DCE6F2]
                   rounded-2xl
                   px-5 py-3
                   text-gray-700
                   focus:outline-none"
        >

            <option value="">
                Semua Tahun
            </option>

            <?php for($i = date('Y'); $i >= 2020; $i--): ?>

                <option value="<?php echo e($i); ?>" <?php echo e(request('tahun') == $i ? 'selected' : ''); ?>>

                    <?php echo e($i); ?>


                </option>

            <?php endfor; ?>

        </select>

        
        <a
            id="btn-cetak-pdf"
            href="<?php echo e(route('admin.laporan.cetak', ['bulan' => request('bulan'), 'tahun' => request('tahun')])); ?>"
            target="_blank" class="bg-[#005BA9]
                   hover:bg-[#004A8A]
                   text-white
                   font-semibold
                   px-6 py-3
                   rounded-2xl
                   transition
                   inline-block"
        >

            Preview Laporan PDF

        </a>

    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

        
        <div class="bg-white rounded-[30px]
                    p-8 border border-[#E5EDF6]
                    shadow-sm relative overflow-hidden">

            <div class="absolute -top-10 -right-10
                        w-40 h-40 rounded-full
                        bg-[#EEF5FD]">
            </div>

            <div class="relative z-10">

                <div class="w-16 h-16 rounded-2xl
                            bg-[#005BA9]
                            flex items-center justify-center
                            shadow-lg text-3xl">

                    👶

                </div>

                <h2 id="text-totalAnak" class="mt-6 text-5xl font-black text-[#1E293B]">

                    <?php echo e($totalAnak); ?>


                </h2>

                <p class="mt-2 text-gray-500 text-lg">

                    Total Anak

                </p>

            </div>

        </div>

        
        <div class="bg-white rounded-[30px]
                    p-8 border border-[#E5EDF6]
                    shadow-sm relative overflow-hidden">

            <div class="absolute -top-10 -right-10
                        w-40 h-40 rounded-full
                        bg-[#EEF5FD]">
            </div>

            <div class="relative z-10">

                <div class="w-16 h-16 rounded-2xl
                            bg-[#0078C1]
                            flex items-center justify-center
                            shadow-lg text-3xl">

                    👦

                </div>

                <h2 id="text-laki" class="mt-6 text-5xl font-black text-[#1E293B]">

                    <?php echo e($laki); ?>


                </h2>

                <p class="mt-2 text-gray-500 text-lg">

                    Anak Laki-Laki

                </p>

            </div>

        </div>

        
        <div class="bg-white rounded-[30px]
                    p-8 border border-[#E5EDF6]
                    shadow-sm relative overflow-hidden">

            <div class="absolute -top-10 -right-10
                        w-40 h-40 rounded-full
                        bg-[#FFF0FA]">
            </div>

            <div class="relative z-10">

                <div class="w-16 h-16 rounded-2xl
                            bg-[#FD4BC7]
                            flex items-center justify-center
                            shadow-lg text-3xl">

                    👧

                </div>

                <h2 id="text-perempuan" class="mt-6 text-5xl font-black text-[#1E293B]">

                    <?php echo e($perempuan); ?>


                </h2>

                <p class="mt-2 text-gray-500 text-lg">

                    Anak Perempuan

                </p>

            </div>

        </div>

    </div>


    
    <div class="grid grid-cols-1
                xl:grid-cols-2 gap-8">

        
        <div class="bg-white rounded-[28px]
                    border border-[#E5EDF6]
                    p-5 shadow-sm">

            <div class="mb-4">

                <h2 class="text-xl font-black text-[#1E293B]">

                    Status Gizi Anak

                </h2>

                <p class="mt-1 text-xs text-gray-500">

                    Berdasarkan data pemeriksaan terbaru.

                </p>

            </div>

            <canvas id="statusChart"
                height="72"></canvas>

        </div>

        
        <div class="bg-white rounded-[28px]
                    border border-[#E5EDF6]
                    p-5 shadow-sm">

            <div class="mb-4">

                <h2 class="text-xl font-black text-[#1E293B]">

                    Distribusi Jenis Kelamin

                </h2>

                <p class="mt-1 text-xs text-gray-500">

                    Perbandingan jumlah anak.

                </p>

            </div>

            <canvas id="genderChart"
                height="72"></canvas>

        </div>

        
        <div class="bg-white rounded-[40px]
                    border border-[#E5EDF6]
                    p-8 shadow-sm xl:col-span-2">

            <div class="mb-8">

                <h2 class="text-3xl font-black text-[#1E293B]">

                    Kelompok Usia Anak

                </h2>

                <p class="mt-2 text-gray-500">

                    Distribusi usia anak berdasarkan
                    data pertumbuhan terbaru.

                </p>

            </div>

            <canvas id="usiaChart"
                height="110"></canvas>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0"></script>

<script>
    // Registrasi plugin datalabels secara global
    Chart.register(ChartDataLabels);

    // Konfigurasi default untuk angka yang muncul
    const datalabelsConfig = {
        color: '#ffffff', // Warna teks angka
        font: {
            weight: 'bold',
            size: 14
        },
        formatter: function(value, context) {
            // Sembunyikan angka jika nilainya 0 agar grafik tidak terlalu penuh
            return value > 0 ? value : '';
        }
    };

    // =========================
    // STATUS GIZI
    // =========================
    let statusChartInstance = new Chart(
        document.getElementById('statusChart'),
        {
            type: 'bar',
            data: {
                labels: ['Belum Dicek', 'Stunting Berat', 'Stunting', 'Normal', 'Tinggi'],
                datasets: [{
                    data: [
                        <?php echo e($belumDicek); ?>, <?php echo e($stuntingBerat); ?>, <?php echo e($stunting); ?>, <?php echo e($normal); ?>, <?php echo e($tinggi); ?>

                    ],
                    backgroundColor: ['#94A3B8', '#FF4D4F', '#FFB200', '#00C951', '#8B5CF6'],
                    borderRadius: 18
                }]
            },
            options: {
                responsive: true,
                plugins: { 
                    legend: { display: false },
                    // Terapkan plugin datalabels di sini
                    datalabels: {
                        ...datalabelsConfig,
                        anchor: 'center',
                        align: 'center',
                    }
                },
                layout: { padding: { top: 20 } }, // Tambah ruang di atas agar angka tidak terpotong jika angkanya besar
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1, precision: 0 }
                    }
                }
            }
        }
    );

    // =========================
    // GENDER
    // =========================
    let genderChartInstance = new Chart(
        document.getElementById('genderChart'),
        {
            type: 'doughnut',
            data: {
                labels: ['Laki-Laki', 'Perempuan'],
                datasets: [{
                    data: [<?php echo e($laki); ?>, <?php echo e($perempuan); ?>],
                    backgroundColor: ['#0078C1', '#FD4BC7'],
                    borderWidth: 0
                }]
            },
            options: { 
                responsive: true, 
                cutout: '78%',
                plugins: {
                    datalabels: {
                        ...datalabelsConfig,
                        color: '#1E293B', // Warna gelap untuk donat chart agar kontras
                        anchor: 'center',
                        align: 'center',
                    }
                }
            }
        }
    );

    // =========================
    // USIA DETAIL
    // =========================
    let usiaChartInstance = new Chart(
        document.getElementById('usiaChart'),
        {
            type: 'line',
            data: {
                labels: ['0-6', '7-12', '13-18', '19-24', '25-36', '37-48', '49-60'],
                datasets: [{
                    label: 'Jumlah Anak',
                    data: [
                        <?php echo e($usia0_6 ?? 0); ?>, <?php echo e($usia7_12 ?? 0); ?>, <?php echo e($usia13_18 ?? 0); ?>,
                        <?php echo e($usia19_24 ?? 0); ?>, <?php echo e($usia25_36 ?? 0); ?>, <?php echo e($usia37_48 ?? 0); ?>,
                        <?php echo e($usia49_60 ?? 0); ?>

                    ],
                    borderColor: '#005BA9',
                    backgroundColor: 'rgba(0,91,169,0.08)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 4,
                    pointRadius: 5
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    datalabels: {
                        color: '#005BA9', // Warna biru menyesuaikan garis
                        font: { weight: 'bold', size: 12 },
                        anchor: 'end', // Posisikan di atas titik kordinat
                        align: 'top',
                        offset: 4,
                        formatter: function(value) {
                            return value > 0 ? value : '';
                        }
                    }
                },
                layout: { padding: { top: 20 } },
                scales: { y: { beginAtZero: true } }
            }
        }
    );

    // =========================
    // LOGIKA AJAX UNTUK FILTER (TETAP SAMA)
    // =========================
    const filterBulan = document.getElementById('filter-bulan');
    const filterTahun = document.getElementById('filter-tahun');
    const btnCetakPdf = document.getElementById('btn-cetak-pdf');

    function updateDataLaporan() {
        let bulan = filterBulan.value;
        let tahun = filterTahun.value;

        btnCetakPdf.href = `<?php echo e(route('kader.laporan.cetak')); ?>?bulan=${bulan}&tahun=${tahun}`;

        let url = new URL(window.location.href);
        url.searchParams.set('bulan', bulan);
        url.searchParams.set('tahun', tahun);

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('text-totalAnak').innerText = data.totalAnak;
            document.getElementById('text-laki').innerText = data.laki;
            document.getElementById('text-perempuan').innerText = data.perempuan;

            statusChartInstance.data.datasets[0].data = [
                data.belumDicek, data.stuntingBerat, data.stunting, data.normal, data.tinggi
            ];
            statusChartInstance.update();

            genderChartInstance.data.datasets[0].data = [data.laki, data.perempuan];
            genderChartInstance.update();

            usiaChartInstance.data.datasets[0].data = [
                data.usia0_6, data.usia7_12, data.usia13_18, data.usia19_24, 
                data.usia25_36, data.usia37_48, data.usia49_60
            ];
            usiaChartInstance.update();
        })
        .catch(error => console.error('Gagal mengambil data:', error));
    }

    filterBulan.addEventListener('change', updateDataLaporan);
    filterTahun.addEventListener('change', updateDataLaporan);

    // Bypass BFCache jika kembali dari PDF
    window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
            window.location.reload();
        }
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/laporan.blade.php ENDPATH**/ ?>