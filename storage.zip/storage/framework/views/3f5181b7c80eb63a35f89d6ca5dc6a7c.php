
<div class="flex flex-col flex-1 h-full min-h-[calc(100vh-6rem)] justify-between">

    
    <div class="flex flex-col flex-1">
        
        
        <div class="px-4 py-4 border-b border-slate-100 flex-shrink-0 sticky top-0 bg-white z-10">
            <div class="flex items-center gap-3 px-4 py-3.5 rounded-2xl"
                 style="background: #EEF4FF; border: 1px solid #C7D9F8;">
                <div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                     style="background: linear-gradient(135deg, #005BA9, #0EA5E9);">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                    </svg>
                </div>
                <div class="overflow-hidden">
                    <p class="font-bold text-sm text-slate-800 truncate leading-snug">
                        <?php echo e(Auth::user()?->nama ?? 'Kader'); ?>

                    </p>
                    <span class="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-semibold capitalize"
                          style="background: rgba(124,77,255,0.12); color: #7C4DFF;">
                        <?php echo e(str_replace('_', ' ', Auth::user()?->role ?? 'Kader Posyandu')); ?>

                    </span>
                </div>
            </div>
        </div>

        
        <nav class="flex-1 px-4 py-5 space-y-2 overflow-y-auto">

            <p class="px-3 pb-3 text-[10px] font-bold tracking-widest uppercase text-slate-400">
                Menu Utama
            </p>

            
            <a href="<?php echo e(route('kader.dashboard')); ?>"
               class="flex items-center gap-3 px-4 py-3.5 rounded-2xl font-semibold text-sm transition-all duration-200
                      <?php echo e(request()->routeIs('kader.dashboard') ? 'text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'); ?>"
               style="<?php echo e(request()->routeIs('kader.dashboard') ? 'background: linear-gradient(135deg, #0D2B6B, #1A4A9A);' : ''); ?>">
                <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                     style="<?php echo e(request()->routeIs('kader.dashboard') ? 'background: rgba(255,255,255,0.15);' : 'background: #EEF4FF;'); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24"
                         stroke="<?php echo e(request()->routeIs('kader.dashboard') ? 'white' : '#1A4A9A'); ?>" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
                Data Anak
            </a>

            
            <a href="<?php echo e(route('kader.rekomendasi')); ?>"
               class="flex items-center gap-3 px-4 py-3.5 rounded-2xl font-semibold text-sm transition-all duration-200
                      <?php echo e(request()->routeIs('kader.rekomendasi') ? 'text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'); ?>"
               style="<?php echo e(request()->routeIs('kader.rekomendasi') ? 'background: linear-gradient(135deg, #7C4DFF, #5e35b1);' : ''); ?>">
                <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                     style="<?php echo e(request()->routeIs('kader.rekomendasi') ? 'background: rgba(255,255,255,0.15);' : 'background: #F5F1FF;'); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24"
                         stroke="<?php echo e(request()->routeIs('kader.rekomendasi') ? 'white' : '#7C4DFF'); ?>" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L5.414 14.881A2 2 0 004 16.732V21a1 1 0 001 1h14a1 1 0 001-1v-4.268a2 2 0 00-.572-1.304zM12 4a4 4 0 110 8 4 4 0 010-8z"/>
                    </svg>
                </div>
                Buat Rekomendasi Nutrisi
            </a>

            
            <a href="<?php echo e(route('kader.laporan')); ?>"
               class="flex items-center gap-3 px-4 py-3.5 rounded-2xl font-semibold text-sm transition-all duration-200
                      <?php echo e(request()->routeIs('kader.laporan') ? 'text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'); ?>"
               style="<?php echo e(request()->routeIs('kader.laporan') ? 'background: linear-gradient(135deg, #00B894, #00957a);' : ''); ?>">
                <div class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                     style="<?php echo e(request()->routeIs('kader.laporan') ? 'background: rgba(255,255,255,0.15);' : 'background: #F0FFFA;'); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] h-[18px]" fill="none" viewBox="0 0 24 24"
                         stroke="<?php echo e(request()->routeIs('kader.laporan') ? 'white' : '#00B894'); ?>" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                </div>
                Data Laporan
            </a>

        </nav>
    </div>

    
    <div class="mt-auto px-4 py-4 border-t border-slate-100 flex-shrink-0 sticky bottom-0 bg-white w-full">
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-2xl font-semibold text-sm text-red-500 bg-red-50 hover:bg-red-100 border border-red-100 transition-all duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
                Logout
            </button>
        </form>
    </div>

</div><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/components/sidebarkader.blade.php ENDPATH**/ ?>