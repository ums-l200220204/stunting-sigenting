



<?php $__env->startSection('title', 'Kelola Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="w-full min-h-screen bg-[#F5F7FA]">

    
    <div class="mb-10">

        <div class="flex items-center justify-between">

            <div>

                <h1 class="text-5xl font-black text-[#1E293B]">

                    Kelola Pengguna

                </h1>

                <p class="text-gray-500 text-lg mt-3">

                    Kelola data pengguna berdasarkan
                    role Admin, Kader, dan Orang Tua.

                </p>

            </div>

            
            <div class="hidden lg:flex
                        items-center justify-center
                        w-24 h-24 rounded-[32px]
                        bg-gradient-to-br
                        from-[#005BA9]
                        to-[#0078C1]
                        shadow-xl">

                <svg xmlns="http://www.w3.org/2000/svg"
                    class="w-12 h-12 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor">

                    <path stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M17 20h5V4H2v16h5m10
                        0v-5a3 3 0 00-3-3H10a3
                        3 0 00-3 3v5m10 0H7m5-12a3
                        3 0 110 6 3 3 0 010-6z"/>

                </svg>

            </div>

        </div>

    </div>

    
    <?php if(session('success')): ?>

        <div class="mb-8
                    bg-green-50
                    border border-green-200
                    rounded-3xl
                    p-6">

            <div class="text-green-700
                        font-bold
                        text-lg">

                <?php echo e(session('success')); ?>


            </div>

        </div>

    <?php endif; ?>

    
    <div class="grid grid-cols-1
                md:grid-cols-3
                gap-6 mb-10">

        
        <div class="bg-white rounded-[32px]
                    p-8 border border-[#E5EDF6]
                    shadow-sm hover:shadow-md
                    transition duration-300">

            <div class="flex items-center justify-between">

                <div>

                    <div class="text-sm
                                text-gray-400
                                font-semibold">

                        Total Admin

                    </div>

                    <div class="text-4xl
                                font-black
                                text-[#1E3A8A] mt-3">

                        <?php echo e($totalAdmin); ?>


                    </div>

                </div>

                <div class="w-16 h-16
                            rounded-3xl
                            bg-[#EEF4FF]
                            flex items-center
                            justify-center">

                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="w-8 h-8 text-[#1E3A8A]"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M12 14l9-5-9-5-9
                            5 9 5z"/>

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M12 14l6.16-3.422A12.083
                            12.083 0 0112 20.055a12.083
                            12.083 0 01-6.16-9.477L12
                            14z"/>

                    </svg>

                </div>

            </div>

        </div>

        
        <div class="bg-white rounded-[32px]
                    p-8 border border-[#E5EDF6]
                    shadow-sm hover:shadow-md
                    transition duration-300">

            <div class="flex items-center justify-between">

                <div>

                    <div class="text-sm
                                text-gray-400
                                font-semibold">

                        Total Kader

                    </div>

                    <div class="text-4xl
                                font-black
                                text-[#0078C1] mt-3">

                        <?php echo e($totalKader); ?>


                    </div>

                </div>

                <div class="w-16 h-16
                            rounded-3xl
                            bg-[#EEF5FD]
                            flex items-center
                            justify-center">

                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="w-8 h-8 text-[#0078C1]"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M17 20h5V4H2v16h5m10
                            0v-5a3 3 0 00-3-3H10a3
                            3 0 00-3 3v5m10 0H7m5-12a3
                            3 0 110 6 3 3 0 010-6z"/>

                    </svg>

                </div>

            </div>

        </div>

        
        <div class="bg-white rounded-[32px]
                    p-8 border border-[#E5EDF6]
                    shadow-sm hover:shadow-md
                    transition duration-300">

            <div class="flex items-center justify-between">

                <div>

                    <div class="text-sm
                                text-gray-400
                                font-semibold">

                        Total Orang Tua

                    </div>

                    <div class="text-4xl
                                font-black
                                text-[#10B981] mt-3">

                        <?php echo e($totalOrangTua); ?>


                    </div>

                </div>

                <div class="w-16 h-16
                            rounded-3xl
                            bg-[#ECFDF5]
                            flex items-center
                            justify-center">

                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="w-8 h-8 text-[#10B981]"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M17 21v-2a4 4 0 00-4-4H5a4
                            4 0 00-4 4v2"/>

                        <circle cx="9"
                                cy="7"
                                r="4"
                                stroke-width="2"/>

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M23 21v-2a4 4 0 00-3-3.87"/>

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M16 3.13a4 4 0 010 7.75"/>

                    </svg>

                </div>

            </div>

        </div>

    </div>

    
    <div class="flex flex-col xl:flex-row
                xl:items-center
                xl:justify-between
                gap-6 mb-8">

        
        <div class="flex flex-wrap gap-4">

            <a href="<?php echo e(route('admin.pengguna')); ?>"
               class="px-6 py-4 rounded-2xl
                      font-bold text-lg
                      transition duration-300
                      <?php echo e(!request('role')
                            ? 'bg-gradient-to-r from-[#005BA9] to-[#0078C1] text-white shadow-lg'
                            : 'bg-white border border-[#E5EDF6] text-gray-600 hover:border-[#0078C1]'); ?>">

                Semua

            </a>

            <a href="<?php echo e(route('admin.pengguna', ['role' => 'admin'])); ?>"
               class="px-6 py-4 rounded-2xl
                      font-bold text-lg
                      transition duration-300
                      <?php echo e(request('role') == 'admin'
                            ? 'bg-[#1E3A8A] text-white shadow-lg'
                            : 'bg-white border border-[#E5EDF6] text-gray-600 hover:border-[#1E3A8A]'); ?>">

                Admin

            </a>

            <a href="<?php echo e(route('admin.pengguna', ['role' => 'kader'])); ?>"
               class="px-6 py-4 rounded-2xl
                      font-bold text-lg
                      transition duration-300
                      <?php echo e(request('role') == 'kader'
                            ? 'bg-[#0078C1] text-white shadow-lg'
                            : 'bg-white border border-[#E5EDF6] text-gray-600 hover:border-[#0078C1]'); ?>">

                Kader

            </a>

            <a href="<?php echo e(route('admin.pengguna', ['role' => 'orang_tua'])); ?>"
               class="px-6 py-4 rounded-2xl
                      font-bold text-lg
                      transition duration-300
                      <?php echo e(request('role') == 'orang_tua'
                            ? 'bg-[#10B981] text-white shadow-lg'
                            : 'bg-white border border-[#E5EDF6] text-gray-600 hover:border-[#10B981]'); ?>">

                Orang Tua

            </a>

        </div>

        
        <div class="flex flex-col md:flex-row gap-4">

            
            <div class="relative">

                <input type="text"
                       id="search"
                       placeholder="Cari pengguna..."
                       class="w-full md:w-[320px]
                              h-16 rounded-2xl
                              border border-[#E5EDF6]
                              bg-white
                              pl-14 pr-6
                              text-lg
                              focus:outline-none
                              focus:ring-2
                              focus:ring-[#0078C1]/20">

                <svg xmlns="http://www.w3.org/2000/svg"
                     class="w-6 h-6 absolute
                            left-5 top-5
                            text-gray-400"
                     fill="none"
                     viewBox="0 0 24 24"
                     stroke="currentColor">

                    <path stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M21 21l-4.35-4.35m1.85-5.15a7
                          7 0 11-14 0 7 7 0 0114 0z"/>

                </svg>

            </div>

            
            <a href="<?php echo e(route('admin.pengguna.create')); ?>"
               class="h-16 px-8 rounded-2xl
                      bg-gradient-to-r
                      from-[#005BA9]
                      to-[#0078C1]
                      text-white text-lg
                      font-bold
                      flex items-center
                      justify-center
                      shadow-lg hover:scale-105
                      transition duration-300">

                + Tambah Pengguna

            </a>

        </div>

    </div>

    
    <div class="relative overflow-hidden
                bg-white rounded-[40px]
                shadow-lg border border-[#E5EDF6]
                p-8 md:p-10">

        <div class="relative z-10">

            <div class="overflow-x-auto">

                <table class="w-full min-w-[1100px]">

                    <thead>

                        <tr class="border-b border-[#E5EDF6]">

                            <th class="text-left py-5 px-4 text-gray-400 font-bold">
                                #
                            </th>

                            <th class="text-left py-5 px-4 text-gray-400 font-bold">
                                Nama
                            </th>

                            <th class="text-left py-5 px-4 text-gray-400 font-bold">
                                Role
                            </th>

                            <th class="text-left py-5 px-4 text-gray-400 font-bold">
                                Email
                            </th>

                            <th class="text-left py-5 px-4 text-gray-400 font-bold">
                                Anak
                            </th>

                            <th class="text-center py-5 px-4 text-gray-400 font-bold">
                                Aksi
                            </th>

                        </tr>

                    </thead>

                    <tbody id="tableBody">

                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr onclick="window.location='<?php echo e(route('admin.pengguna.detail', $user->id)); ?>'"
                                class="border-b
                                       border-[#F1F5F9]
                                       hover:bg-[#F8FBFF]
                                       duration-200
                                       cursor-pointer">

                                
                                <td class="py-5 px-4 text-gray-500">

                                    <?php echo e($users->firstItem() + $index); ?>


                                </td>

                                
                                <td class="py-5 px-4">

                                    <div class="font-bold
                                                text-[#1E293B]
                                                text-lg">

                                        <?php echo e($user->nama); ?>


                                    </div>

                                </td>

                                
                                <td class="py-5 px-4">

                                    <?php if($user->role == 'admin'): ?>

                                        <span class="inline-flex items-center
                                                     px-4 py-2
                                                     rounded-xl
                                                     bg-[#EEF4FF]
                                                     text-[#1E3A8A]
                                                     text-sm font-bold">

                                            Admin

                                        </span>

                                    <?php elseif($user->role == 'kader'): ?>

                                        <span class="inline-flex items-center
                                                     px-4 py-2
                                                     rounded-xl
                                                     bg-[#EEF5FD]
                                                     text-[#0078C1]
                                                     text-sm font-bold">

                                            Kader

                                        </span>

                                    <?php else: ?>

                                        <span class="inline-flex items-center
                                                     px-4 py-2
                                                     rounded-xl
                                                     bg-[#ECFDF5]
                                                     text-[#10B981]
                                                     text-sm font-bold">

                                            Orang Tua

                                        </span>

                                    <?php endif; ?>

                                </td>

                                
                                <td class="py-5 px-4 text-gray-600">

                                    <?php echo e($user->email); ?>


                                </td>

                                
                                <td class="py-5 px-4 text-gray-600">

                                    <?php if($user->role == 'orang_tua'): ?>

                                        <span class="font-semibold text-[#1E293B]">

                                            <?php echo e($user->nama_anak ?? '-'); ?>


                                        </span>

                                    <?php else: ?>

                                        -

                                    <?php endif; ?>

                                </td>

                                
                                <td class="py-5 px-4">

                                    <div class="flex items-center
                                                justify-center
                                                gap-3">

                                        
                                        <a href="<?php echo e(route('admin.pengguna.edit', $user->id)); ?>"
                                           onclick="event.stopPropagation()"
                                           class="w-12 h-12
                                                  rounded-2xl
                                                  border border-[#D6E4F0]
                                                  flex items-center
                                                  justify-center
                                                  hover:bg-[#EEF5FD]
                                                  text-[#0078C1]
                                                  duration-300">

                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                class="w-5 h-5"
                                                fill="none"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor">

                                                <path stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    stroke-width="2"
                                                    d="M11 5H6a2 2 0 00-2 2v11a2 2 0
                                                    002 2h11a2 2 0 002-2v-5m-1.586-9.414a2
                                                    2 0 112.828 2.828L11.828
                                                    17H9v-2.828l8.414-8.586z"/>

                                            </svg>

                                        </a>

                                        
                                        <form action="<?php echo e(route('admin.pengguna.hapus', $user->id)); ?>"
                                              method="POST"
                                              onsubmit="return confirm('Yakin ingin menghapus pengguna ini?')">

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                type="submit"
                                                onclick="event.stopPropagation()"
                                                class="w-12 h-12
                                                       rounded-2xl
                                                       border border-[#D6E4F0]
                                                       flex items-center
                                                       justify-center
                                                       hover:bg-[#FEF2F2]
                                                       text-[#EF4444]
                                                       duration-300">

                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                     class="w-5 h-5"
                                                     fill="none"
                                                     viewBox="0 0 24 24"
                                                     stroke="currentColor">

                                                    <path stroke-linecap="round"
                                                          stroke-linejoin="round"
                                                          stroke-width="2"
                                                          d="M19 7l-.867 12.142A2 2 0
                                                          0116.138 21H7.862a2 2 0
                                                          01-1.995-1.858L5 7m5
                                                          4v6m4-6v6M9 7V4a1 1 0
                                                          011-1h4a1 1 0 011
                                                          1v3m-7 0h8"/>

                                                </svg>

                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td colspan="6"
                                    class="text-center py-20">

                                    <div class="text-2xl
                                                font-bold
                                                text-gray-400">

                                        Data pengguna kosong

                                    </div>

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            
            <div class="mt-10">

                <?php echo e($users->links()); ?>


            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/kelolapengguna.blade.php ENDPATH**/ ?>