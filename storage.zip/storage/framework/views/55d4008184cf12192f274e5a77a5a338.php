



<?php $__env->startSection('title', 'Edit Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="min-h-screen bg-[#F5F7FA]">

    
    <div class="max-w-6xl mx-auto px-6 py-10">

        
        <div class="bg-white
                    rounded-[36px]
                    shadow-xl
                    overflow-hidden
                    border border-[#E5EDF6]">

            
            <div class="bg-gradient-to-r
                        from-[#005BA9]
                        to-[#0078C1]
                        px-8 py-8">

                <div class="flex items-center gap-5">

                    
                    <div class="w-20 h-20
                                rounded-[28px]
                                bg-white/15
                                border border-white/20
                                flex items-center
                                justify-center">

                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="w-10 h-10 text-white"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor">

                            <path stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M11 5h2m-1-1v2m6 2v10a2
                                2 0 01-2 2H6a2 2 0 01-2-2V8a2
                                2 0 012-2h2l2-2h4l2 2h2a2
                                2 0 012 2z"/>

                        </svg>

                    </div>

                    
                    <div>

                        <h1 class="text-4xl
                                   font-black
                                   text-white">

                            Edit Pengguna

                        </h1>

                        <p class="text-white/80
                                  mt-2 text-lg">

                            Perbarui data pengguna sistem

                        </p>

                    </div>

                </div>

            </div>

            
            <div class="p-8 md:p-10">

                
                <?php if($errors->any()): ?>

                    <div class="mb-8
                                bg-red-50
                                border border-red-200
                                rounded-3xl
                                p-6">

                        <div class="font-bold
                                    text-red-500
                                    text-lg mb-4">

                            Terjadi Kesalahan

                        </div>

                        <ul class="space-y-2">

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="text-red-500 text-sm">

                                    • <?php echo e($error); ?>


                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>

                    </div>

                <?php endif; ?>

                
                <form action="<?php echo e(route('admin.pengguna.update', $user->id)); ?>"
                      method="POST">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="grid
                                grid-cols-1
                                lg:grid-cols-2
                                gap-x-8 gap-y-7">

                        
                        <div class="lg:col-span-2">

                            <label class="block
                                          font-bold
                                          text-[#1E293B]
                                          mb-3">

                                Role

                            </label>

                            <input type="text"
                                value="<?php echo e(ucfirst(str_replace('_', ' ', $user->role))); ?>"
                                readonly
                                class="w-full h-[62px]
                                       rounded-2xl
                                       border border-[#DCE6F0]
                                       bg-gray-100
                                       px-6">

                        </div>

                        
                        
                        

                        
                        <div>

                            <label class="block
                                          font-bold
                                          text-[#1E293B]
                                          mb-3">

                                Nama

                            </label>

                            <input type="text"
                                name="nama"
                                value="<?php echo e(old('nama', $user->nama)); ?>"
                                class="w-full h-[62px]
                                       rounded-2xl
                                       border border-[#DCE6F0]
                                       bg-[#F8FBFF]
                                       px-6">

                        </div>

                        
                        <div>

                            <label class="block
                                          font-bold
                                          text-[#1E293B]
                                          mb-3">

                                Email

                            </label>

                            <input type="email"
                                name="email"
                                value="<?php echo e(old('email', $user->email)); ?>"
                                class="w-full h-[62px]
                                       rounded-2xl
                                       border border-[#DCE6F0]
                                       bg-[#F8FBFF]
                                       px-6">

                        </div>

                        
                        <div>

                            <label class="block
                                          font-bold
                                          text-[#1E293B]
                                          mb-3">

                                Nomor HP

                            </label>

                            <input type="text"
                                name="nomor_hp"
                                value="<?php echo e(old('nomor_hp', $user->nomor_hp)); ?>"
                                class="w-full h-[62px]
                                       rounded-2xl
                                       border border-[#DCE6F0]
                                       bg-[#F8FBFF]
                                       px-6">

                        </div>

                        
                        <div class="lg:col-span-2">

                            <label class="block
                                          font-bold
                                          text-[#1E293B]
                                          mb-3">

                                Alamat

                            </label>

                            <textarea name="alamat"
                                rows="5"
                                class="w-full rounded-3xl
                                       border border-[#DCE6F0]
                                       bg-[#F8FBFF]
                                       px-6 py-5"><?php echo e(old('alamat', $user->alamat)); ?></textarea>

                        </div>

                    </div>

                    
                    
                    
                    <?php if($user->role == 'orang_tua' && $anak): ?>

                        <div class="mt-12
                                    bg-[#ECFDF5]
                                    rounded-[32px]
                                    p-8
                                    border border-[#BBF7D0]">

                            <h3 class="text-3xl
                                       font-black
                                       text-[#047857]
                                       mb-8">

                                Data Anak

                            </h3>

                            <div class="grid
                                        grid-cols-1
                                        lg:grid-cols-2
                                        gap-8">

                                
                                <div>

                                    <label class="block
                                                  font-bold
                                                  text-[#1E293B]
                                                  mb-3">

                                        Nama Anak

                                    </label>

                                    <input type="text"
                                        name="nama_anak"
                                        value="<?php echo e(old('nama_anak', $anak->nama_anak)); ?>"
                                        class="w-full h-[62px]
                                               rounded-2xl
                                               border border-[#DCE6F0]
                                               bg-white
                                               px-6">

                                </div>

                                
                                <div>

                                    <label class="block
                                                  font-bold
                                                  text-[#1E293B]
                                                  mb-3">

                                        Jenis Kelamin

                                    </label>

                                    <select name="jenis_kelamin"
                                        class="w-full h-[62px]
                                               rounded-2xl
                                               border border-[#DCE6F0]
                                               bg-white
                                               px-6">

                                        <option value="L"
                                            <?php echo e($anak->jenis_kelamin == 'L' ? 'selected' : ''); ?>>

                                            Laki-laki

                                        </option>

                                        <option value="P"
                                            <?php echo e($anak->jenis_kelamin == 'P' ? 'selected' : ''); ?>>

                                            Perempuan

                                        </option>

                                    </select>

                                </div>

                                
                                <div>

                                    <label class="block
                                                  font-bold
                                                  text-[#1E293B]
                                                  mb-3">

                                        Tanggal Lahir

                                    </label>

                                    <input type="date"
                                        name="tanggal_lahir"
                                        value="<?php echo e(old('tanggal_lahir', $anak->tanggal_lahir)); ?>"
                                        class="w-full h-[62px]
                                               rounded-2xl
                                               border border-[#DCE6F0]
                                               bg-white
                                               px-6">

                                </div>

                                
                                <div>

                                    <label class="block
                                                  font-bold
                                                  text-[#1E293B]
                                                  mb-3">

                                        Usia

                                    </label>

                                    <input type="text"
                                        readonly
                                        value="<?php echo e((int) \Carbon\Carbon::parse($anak->tanggal_lahir)->diffInMonths(now())); ?> Bulan"
                                        class="w-full h-[62px]
                                               rounded-2xl
                                               border border-[#DCE6F0]
                                               bg-gray-100
                                               px-6">

                                </div>

                            </div>

                        </div>

                    <?php endif; ?>

                    
                    <div class="flex flex-wrap gap-5 mt-12">

                        
                        <button type="submit"
                            class="inline-flex items-center
                                   justify-center
                                   h-16 px-10
                                   rounded-2xl
                                   bg-gradient-to-r
                                   from-[#005BA9]
                                   to-[#0078C1]
                                   text-white
                                   text-lg
                                   font-bold
                                   shadow-lg
                                   hover:scale-105
                                   transition duration-300">

                            Simpan Perubahan

                        </button>

                        
                        <a href="<?php echo e(route('admin.pengguna.detail', $user->id)); ?>"
                           class="inline-flex items-center
                                  justify-center
                                  h-16 px-10
                                  rounded-2xl
                                  border border-[#DCE6F0]
                                  bg-white
                                  text-[#1E293B]
                                  text-lg
                                  font-bold
                                  hover:bg-[#F8FBFF]
                                  transition duration-300">

                            Kembali

                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/editpengguna.blade.php ENDPATH**/ ?>