

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('role', 'Admin'); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('components.sidebaradmin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="flex justify-between items-center">

    <button class="border-2 border-blue-500 text-blue-500 px-8 py-3 rounded-xl text-xl">
        + TAMBAH PENGGUNA
    </button>

    <input type="text"
        placeholder="Search..."
        class="border p-3 rounded-xl w-[300px]">

</div>

<div class="mt-10 bg-white rounded-2xl overflow-hidden shadow">

    <table class="w-full">

        <thead class="bg-gray-100">

            <tr>

                <th class="p-5 text-left">#</th>
                <th class="p-5 text-left">Nama Orang Tua</th>
                <th class="p-5 text-left">Role</th>
                <th class="p-5 text-left">E-Mail</th>
                <th class="p-5 text-left">Nama Anak</th>
                <th class="p-5 text-left">Aksi</th>

            </tr>

        </thead>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>