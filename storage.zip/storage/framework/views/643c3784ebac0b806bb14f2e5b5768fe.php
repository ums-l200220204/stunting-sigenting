
<aside id="sidebar"
    class="fixed lg:static
           top-0 left-0 z-50
           w-[300px]
           min-h-screen
           bg-white
           border-r border-[#E5EDF6]
           shadow-sm
           flex flex-col
           transform
           -translate-x-full
           lg:translate-x-0
           transition-all duration-300">

    
    <div class="p-5 border-b border-[#E5EDF6]">

        
        <div class="flex items-center
                    justify-between mb-5">


            
            <button onclick="toggleSidebar()"
                class="lg:hidden w-11 h-11
                       rounded-2xl
                       bg-[#F5F7FA]
                       hover:bg-[#EEF5FD]
                       flex items-center
                       justify-center
                       transition duration-300">

                ✕

            </button>

        </div>

        
        <div class="bg-gradient-to-r
                    from-[#005BA9]
                    to-[#0078C1]
                    rounded-[30px]
                    p-5 shadow-lg">

            <div class="flex items-center gap-4">

                
                <div class="w-16 h-16 rounded-[22px]
                            bg-white/15
                            border border-white/20
                            flex items-center justify-center">

                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="w-8 h-8 text-white"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">

                        <path stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M5.121 17.804A9 9 0 1118.88
                            17.8M15 11a3 3 0 11-6 0 3 3
                            0 016 0z"/>

                    </svg>

                </div>

                
                <div>

                    <h2 class="text-white
                               text-xl
                               font-black">

                        <?php echo e(Auth::user()?->nama ?? 'Admin'); ?>


                    </h2>

                    <p class="text-white/80
                              text-sm mt-1">

                        Administrator Sistem

                    </p>

                </div>

            </div>

        </div>

    </div>

    
    <div class="flex-1 px-5 py-6 space-y-3">

        
        <a href="<?php echo e(route('admin.pengguna')); ?>"
            class="flex items-center gap-4
                   px-5 py-4 rounded-2xl
                   transition duration-300

                   <?php echo e(request()->routeIs('admin.pengguna')
                        ? 'bg-[#EEF5FD] text-[#005BA9] shadow-sm'
                        : 'text-gray-600 hover:bg-[#EEF5FD]'); ?>">

            <div class="w-11 h-11 rounded-2xl
                        flex items-center justify-center

                        <?php echo e(request()->routeIs('admin.pengguna')
                            ? 'bg-[#005BA9] text-white'
                            : 'bg-[#EEF5FD]'); ?>">

                👥

            </div>

            <span class="font-semibold text-[16px]">

                Kelola Pengguna

            </span>

        </a>


        
        <a href="<?php echo e(route('admin.laporan')); ?>"
            class="flex items-center gap-4
                   px-5 py-4 rounded-2xl
                   text-gray-600
                   hover:bg-[#F0FFFA]
                   transition duration-300">

            <div class="w-11 h-11 rounded-2xl
                        bg-[#F0FFFA]
                        flex items-center justify-center">

                📄

            </div>

            <span class="font-semibold text-[16px]">

                Data Laporan

            </span>

        </a>

    </div>

    
    <div class="p-5 border-t border-[#E5EDF6]">

        <form action="<?php echo e(route('logout')); ?>"
            method="POST">

            <?php echo csrf_field(); ?>

            <button type="submit"
                class="w-full flex items-center
                       justify-center gap-3
                       py-4 rounded-2xl
                       bg-red-50 hover:bg-red-100
                       text-red-500 font-bold
                       transition duration-300">

                Logout

            </button>

        </form>

    </div>

</aside>


<div id="sidebarOverlay"
    onclick="toggleSidebar()"
    class="fixed inset-0
           bg-black/40
           z-40 hidden lg:hidden">
</div>


<script>

    function toggleSidebar() {

        const sidebar =
            document.getElementById('sidebar');

        const overlay =
            document.getElementById('sidebarOverlay');

        sidebar.classList.toggle(
            '-translate-x-full'
        );

        overlay.classList.toggle(
            'hidden'
        );
    }

</script><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/components/sidebaradmin.blade.php ENDPATH**/ ?>