<?php echo e($slot); ?>

<?php /**PATH D:\SKRIPSI\stunting\stunting\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>