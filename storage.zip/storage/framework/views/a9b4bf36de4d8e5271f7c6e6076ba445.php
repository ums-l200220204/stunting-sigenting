<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

</head>

<body class="bg-[#f5f5f5] flex items-center justify-center min-h-screen">

    <div class="bg-[#d9d9d9] w-[700px] rounded-3xl p-14">

        <!-- Title -->
        <div class="text-center">

            <h1 class="text-4xl font-bold">
                Silahkan Masukkan Akun Anda
            </h1>

            <p class="text-xl mt-3">
                Enter your email to sign in for this app
            </p>

        </div>

        <!-- Form -->
        <form class="mt-10 space-y-5">

            <!-- Email -->
            <input type="text"
                placeholder="Email/Nomor HP"
                class="w-full h-16 rounded-xl px-5 text-2xl outline-none">

            <!-- Password -->
            <input type="password"
                placeholder="Password"
                class="w-full h-16 rounded-xl px-5 text-2xl outline-none">

            <!-- Button -->
            <button class="w-full bg-black text-white h-16 rounded-xl text-2xl font-semibold">
                Masuk
            </button>

        </form>

        <!-- Divider -->
        <div class="flex items-center gap-5 my-8">

            <div class="flex-1 h-[1px] bg-gray-400"></div>

            <p class="text-xl">
                atau lanjutkan dengan
            </p>

            <div class="flex-1 h-[1px] bg-gray-400"></div>

        </div>

        <!-- Google Button -->
        <button class="w-full bg-white h-16 rounded-xl flex items-center justify-center gap-5">

            <img src="https://cdn-icons-png.flaticon.com/512/281/281764.png"
                class="w-8 h-8">

            <span class="text-2xl">
                Google
            </span>

        </button>

        <!-- Register -->
        <div class="text-center mt-10 text-xl">

            Belum punya akun?

            <a href="<?php echo e(route('register')); ?>"
                class="text-blue-600 font-semibold hover:underline">

                Registrasi

            </a>

        </div>

    </div>

</body>
</html><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/login.blade.php ENDPATH**/ ?>