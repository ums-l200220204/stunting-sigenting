



<?php $__env->startSection('title', 'Tambah Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="min-h-screen bg-[#F5F7FA]">

    
    <div class="max-w-6xl mx-auto px-6 py-10">

        
        <div class="bg-white
                    rounded-[36px]
                    shadow-xl
                    overflow-hidden
                    border border-[#E5EDF6]">

            
            <div class="bg-gradient-to-r
                        from-[#005BA9]
                        to-[#0078C1]
                        px-8 py-8">

                <div class="flex items-center gap-5">

                    
                    <div class="w-20 h-20
                                rounded-[28px]
                                bg-white/15
                                border border-white/20
                                flex items-center
                                justify-center">

                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="w-10 h-10 text-white"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor">

                            <path stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M17 20h5V4H2v16h5m10
                                0v-5a3 3 0 00-3-3H10a3
                                3 0 00-3 3v5m10 0H7m5-12a3
                                3 0 110 6 3 3 0 010-6z"/>

                        </svg>

                    </div>

                    
                    <div>

                        <h1 class="text-4xl
                                   font-black
                                   text-white">

                            Tambah Pengguna

                        </h1>

                        <p class="text-white/80
                                  mt-2 text-lg">

                            Tambahkan data pengguna baru
                            ke dalam sistem

                        </p>

                    </div>

                </div>

            </div>

            
            <div class="p-8 md:p-10">

                
                <?php if($errors->any()): ?>

                    <div class="mb-8
                                bg-red-50
                                border border-red-200
                                rounded-3xl
                                p-6">

                        <div class="font-bold
                                    text-red-500
                                    text-lg mb-4">

                            Terjadi Kesalahan

                        </div>

                        <ul class="space-y-2">

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li class="text-red-500 text-sm">

                                    • <?php echo e($error); ?>


                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>

                    </div>

                <?php endif; ?>

                
                <form action="<?php echo e(route('admin.pengguna.store')); ?>"
                      method="POST">

                    <?php echo csrf_field(); ?>

                    
                    <div class="grid grid-cols-1
                                lg:grid-cols-2
                                gap-x-8 gap-y-7">

                        
                        <div class="lg:col-span-2">

                            <label class="block
                                          font-bold
                                          text-[#1E293B]
                                          mb-3">

                                Role

                            </label>

                            <select id="roleSelect"
                                name="role"
                                class="w-full h-[62px]
                                       rounded-2xl
                                       border border-[#DCE6F0]
                                       bg-[#F8FBFF]
                                       px-6
                                       text-[16px]
                                       focus:outline-none
                                       focus:ring-2
                                       focus:ring-[#0078C1]/20">

                                <option value="">
                                    Pilih Role
                                </option>

                                <option value="admin">
                                    Admin
                                </option>

                                <option value="kader">
                                    Kader
                                </option>

                                <option value="orang_tua">
                                    Orang Tua
                                </option>

                            </select>

                        </div>

                        
                        
                        
                        <div id="adminKaderForm"
                             class="contents hidden">

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Nama Lengkap

                                </label>

                                <input type="text"
                                    name="nama"
                                    placeholder="Masukkan nama lengkap"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Email

                                </label>

                                <input type="email"
                                    name="email"
                                    placeholder="Masukkan email"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Nomor HP

                                </label>

                                <input type="text"
                                    name="nomor_hp"
                                    placeholder="Masukkan nomor HP"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Alamat

                                </label>

                                <textarea name="alamat"
                                    rows="5"
                                    placeholder="Masukkan alamat lengkap"
                                    disabled
                                    class="w-full rounded-3xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6 py-5"></textarea>

                            </div>

                        </div>

                        
                        
                        
                        <div id="orangTuaForm"
                             class="contents hidden">

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Nama Anak

                                </label>

                                <input type="text"
                                    name="nama_anak"
                                    placeholder="Masukkan nama anak"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Nama Orang Tua

                                </label>

                                <input type="text"
                                    name="nama"
                                    placeholder="Masukkan nama orang tua"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Jenis Kelamin

                                </label>

                                <select name="jenis_kelamin"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                                    <option value="">
                                        Pilih Jenis Kelamin
                                    </option>

                                    <option value="L">
                                        Laki-laki
                                    </option>

                                    <option value="P">
                                        Perempuan
                                    </option>

                                </select>

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Email

                                </label>

                                <input type="email"
                                    name="email"
                                    placeholder="Masukkan email"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Tanggal Lahir

                                </label>

                                <input type="date"
                                    name="tanggal_lahir"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Nomor HP

                                </label>

                                <input type="text"
                                    name="nomor_hp"
                                    placeholder="Masukkan nomor HP"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div class="lg:col-span-2">

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Alamat

                                </label>

                                <textarea name="alamat"
                                    rows="5"
                                    placeholder="Masukkan alamat lengkap"
                                    disabled
                                    class="w-full rounded-3xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6 py-5"></textarea>

                            </div>

                        </div>

                        
                        <div id="passwordSection"
                             class="contents hidden">

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Password

                                </label>

                                <input type="password"
                                    name="password"
                                    placeholder="Masukkan password"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                            
                            <div>

                                <label class="block
                                              font-bold
                                              text-[#1E293B]
                                              mb-3">

                                    Konfirmasi Password

                                </label>

                                <input type="password"
                                    name="password_confirmation"
                                    placeholder="Konfirmasi password"
                                    disabled
                                    class="w-full h-[62px]
                                           rounded-2xl
                                           border border-[#DCE6F0]
                                           bg-[#F8FBFF]
                                           px-6">

                            </div>

                        </div>

                    </div>

                    
                    <div class="flex flex-col sm:flex-row
                                justify-center
                                gap-5 mt-10">

                        
                        <button type="submit"
                            class="h-[60px]
                                   px-10
                                   rounded-2xl
                                   bg-gradient-to-r
                                   from-[#005BA9]
                                   to-[#0078C1]
                                   text-white
                                   font-bold
                                   text-lg
                                   shadow-lg
                                   hover:scale-[1.02]
                                   transition duration-300">

                            Simpan Pengguna

                        </button>

                        
                        <a href="<?php echo e(route('admin.pengguna')); ?>"
                            class="h-[60px]
                                   px-10
                                   rounded-2xl
                                   border border-[#DCE6F0]
                                   bg-white
                                   text-[#1E293B]
                                   font-bold
                                   text-lg
                                   flex items-center
                                   justify-center
                                   hover:bg-[#F8FBFF]
                                   transition duration-300">

                            Kembali

                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>


<script>

    const roleSelect =
        document.getElementById(
            'roleSelect'
        );

    const adminKaderForm =
        document.getElementById(
            'adminKaderForm'
        );

    const orangTuaForm =
        document.getElementById(
            'orangTuaForm'
        );

    const passwordSection =
        document.getElementById(
            'passwordSection'
        );

    // =========================
    // ENABLE / DISABLE INPUT
    // =========================
    function toggleInputs(
        container,
        disabled
    ) {

        const inputs =
            container.querySelectorAll(
                'input, select, textarea'
            );

        inputs.forEach(input => {

            input.disabled =
                disabled;
        });
    }

    // DEFAULT
    toggleInputs(
        adminKaderForm,
        true
    );

    toggleInputs(
        orangTuaForm,
        true
    );

    toggleInputs(
        passwordSection,
        true
    );

    roleSelect.addEventListener(
        'change',
        function () {

            const role =
                this.value;

            // RESET
            adminKaderForm.classList.add(
                'hidden'
            );

            orangTuaForm.classList.add(
                'hidden'
            );

            passwordSection.classList.add(
                'hidden'
            );

            toggleInputs(
                adminKaderForm,
                true
            );

            toggleInputs(
                orangTuaForm,
                true
            );

            toggleInputs(
                passwordSection,
                true
            );

            // =====================
            // ADMIN / KADER
            // =====================
            if (
                role === 'admin' ||
                role === 'kader'
            ) {

                adminKaderForm.classList.remove(
                    'hidden'
                );

                passwordSection.classList.remove(
                    'hidden'
                );

                toggleInputs(
                    adminKaderForm,
                    false
                );

                toggleInputs(
                    passwordSection,
                    false
                );
            }

            // =====================
            // ORANG TUA
            // =====================
            if (
                role === 'orang_tua'
            ) {

                orangTuaForm.classList.remove(
                    'hidden'
                );

                passwordSection.classList.remove(
                    'hidden'
                );

                toggleInputs(
                    orangTuaForm,
                    false
                );

                toggleInputs(
                    passwordSection,
                    false
                );
            }
        }
    );

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/tambahpengguna.blade.php ENDPATH**/ ?>