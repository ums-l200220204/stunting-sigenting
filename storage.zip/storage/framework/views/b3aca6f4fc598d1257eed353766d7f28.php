



<?php $__env->startSection('title', 'Detail Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="w-full min-h-screen bg-[#F5F7FA]">

    
    <div class="mb-10 flex items-center justify-between">

        <div>

            <h1 class="text-5xl font-black text-[#1E293B]">

                Detail Pengguna

            </h1>

            <p class="text-gray-500 text-lg mt-3">

                Informasi lengkap data pengguna.

            </p>

        </div>

        
        <div class="hidden lg:flex
                    items-center justify-center
                    w-24 h-24 rounded-[32px]
                    bg-gradient-to-br
                    from-[#005BA9]
                    to-[#0078C1]
                    shadow-xl">

            <svg xmlns="http://www.w3.org/2000/svg"
                 class="w-12 h-12 text-white"
                 fill="none"
                 viewBox="0 0 24 24"
                 stroke="currentColor">

                <path stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M5.121 17.804A13.937 13.937 0 0112
                      16c2.5 0 4.847.655 6.879
                      1.804M15 10a3 3 0 11-6 0
                      3 3 0 016 0z"/>

            </svg>

        </div>

    </div>

    
    <?php if(session('success')): ?>

        <div class="mb-8
                    bg-green-50
                    border border-green-200
                    rounded-3xl
                    p-6">

            <div class="text-green-700
                        font-bold
                        text-lg">

                <?php echo e(session('success')); ?>


            </div>

        </div>

    <?php endif; ?>

    
    <div class="bg-white
                rounded-[40px]
                shadow-lg
                border border-[#E5EDF6]
                overflow-hidden">

        
        <div class="bg-gradient-to-r
                    from-[#005BA9]
                    to-[#0078C1]
                    px-10 py-10">

            <div class="flex items-center gap-6">

                
                <div class="w-28 h-28
                            rounded-full
                            bg-white/20
                            flex items-center
                            justify-center
                            text-white
                            text-5xl
                            font-black">

                    <?php echo e(strtoupper(substr($user->nama, 0, 1))); ?>


                </div>

                
                <div>

                    <h2 class="text-4xl
                               font-black
                               text-white">

                        <?php echo e($user->nama); ?>


                    </h2>

                    <div class="flex flex-wrap gap-4 mt-4">

                        
                        <?php if($user->role == 'admin'): ?>

                            <span class="px-5 py-2
                                         rounded-xl
                                         bg-[#EEF4FF]
                                         text-[#1E3A8A]
                                         font-bold">

                                Admin

                            </span>

                        <?php elseif($user->role == 'kader'): ?>

                            <span class="px-5 py-2
                                         rounded-xl
                                         bg-[#EEF5FD]
                                         text-[#0078C1]
                                         font-bold">

                                Kader

                            </span>

                        <?php else: ?>

                            <span class="px-5 py-2
                                         rounded-xl
                                         bg-[#ECFDF5]
                                         text-[#10B981]
                                         font-bold">

                                Orang Tua

                            </span>

                        <?php endif; ?>

                        
                        <span class="px-5 py-2
                                     rounded-xl
                                     bg-white/20
                                     text-white
                                     font-bold">

                            ID : <?php echo e($user->id); ?>


                        </span>

                    </div>

                </div>

            </div>

        </div>

        
        <div class="p-10">

            
            <div class="mb-10">

                <h3 class="text-3xl
                           font-black
                           text-[#1E293B]
                           mb-8">

                    Informasi Pengguna

                </h3>

                <div class="grid
                            grid-cols-1
                            lg:grid-cols-2
                            gap-8">

                    
                    <div class="bg-[#F8FBFF]
                                rounded-3xl
                                p-8 border border-[#E5EDF6]">

                        <div class="text-sm
                                    text-gray-400
                                    font-semibold mb-3">

                            Email

                        </div>

                        <div class="text-2xl
                                    font-bold
                                    text-[#1E293B]">

                            <?php echo e($user->email); ?>


                        </div>

                    </div>

                    
                    <div class="bg-[#F8FBFF]
                                rounded-3xl
                                p-8 border border-[#E5EDF6]">

                        <div class="text-sm
                                    text-gray-400
                                    font-semibold mb-3">

                            Nomor HP

                        </div>

                        <div class="text-2xl
                                    font-bold
                                    text-[#1E293B]">

                            <?php echo e($user->nomor_hp); ?>


                        </div>

                    </div>

                    
                    <div class="bg-[#F8FBFF]
                                rounded-3xl
                                p-8 border border-[#E5EDF6]">

                        <div class="text-sm
                                    text-gray-400
                                    font-semibold mb-3">

                            Role

                        </div>

                        <div class="text-2xl
                                    font-bold
                                    text-[#1E293B]">

                            <?php echo e(ucfirst(str_replace('_', ' ', $user->role))); ?>


                        </div>

                    </div>

                    
                    <div class="bg-[#F8FBFF]
                                rounded-3xl
                                p-8 border border-[#E5EDF6]">

                        <div class="text-sm
                                    text-gray-400
                                    font-semibold mb-3">

                            Dibuat Pada

                        </div>

                        <div class="text-2xl
                                    font-bold
                                    text-[#1E293B]">

                            <?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d M Y H:i')); ?>


                        </div>

                    </div>

                    
                    <div class="bg-[#F8FBFF]
                                rounded-3xl
                                p-8 border border-[#E5EDF6]
                                lg:col-span-2">

                        <div class="text-sm
                                    text-gray-400
                                    font-semibold mb-3">

                            Alamat

                        </div>

                        <div class="text-xl
                                    font-semibold
                                    text-[#1E293B]
                                    leading-relaxed">

                            <?php echo e($user->alamat); ?>


                        </div>

                    </div>

                </div>

            </div>

            
            <?php if($user->role == 'orang_tua' && $anak): ?>

                <div class="bg-[#ECFDF5]
                            rounded-[32px]
                            p-10 border border-[#BBF7D0]
                            mb-10">

                    <h3 class="text-3xl
                               font-black
                               text-[#047857]
                               mb-8">

                        Data Anak

                    </h3>

                    <div class="grid
                                grid-cols-1
                                md:grid-cols-2
                                xl:grid-cols-4
                                gap-8">

                        
                        <div>

                            <div class="text-sm
                                        text-gray-500
                                        font-semibold mb-2">

                                Nama Anak

                            </div>

                            <div class="text-2xl
                                        font-bold
                                        text-[#1E293B]">

                                <?php echo e($anak->nama_anak); ?>


                            </div>

                        </div>

                        
                        <div>

                            <div class="text-sm
                                        text-gray-500
                                        font-semibold mb-2">

                                Jenis Kelamin

                            </div>

                            <div class="text-2xl
                                        font-bold
                                        text-[#1E293B]">

                                <?php echo e($anak->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?>


                            </div>

                        </div>

                        
                        <div>

                            <div class="text-sm
                                        text-gray-500
                                        font-semibold mb-2">

                                Tanggal Lahir

                            </div>

                            <div class="text-2xl
                                        font-bold
                                        text-[#1E293B]">

                                <?php echo e(\Carbon\Carbon::parse($anak->tanggal_lahir)->format('d M Y')); ?>


                            </div>

                        </div>

                        
                        <div>

                            <div class="text-sm
                                        text-gray-500
                                        font-semibold mb-2">

                                Usia

                            </div>

                            <div class="text-2xl
                                        font-bold
                                        text-[#1E293B]">

                                <?php echo e((int) \Carbon\Carbon::parse($anak->tanggal_lahir)->diffInMonths(now())); ?> Bulan

                            </div>

                        </div>

                    </div>

                </div>

            <?php endif; ?>

            
            <div class="flex flex-wrap gap-5">

                
                <button
                    onclick="openModal()"
                    class="inline-flex items-center
                           justify-center
                           h-16 px-10
                           rounded-2xl
                           bg-gradient-to-r
                           from-[#EF4444]
                           to-[#DC2626]
                           text-white
                           text-lg
                           font-bold
                           shadow-lg
                           hover:scale-105
                           transition duration-300">

                    Reset Password

                </button>

                
                <a href="<?php echo e(route('admin.pengguna')); ?>"
                   class="inline-flex items-center
                          justify-center
                          h-16 px-10
                          rounded-2xl
                          bg-gradient-to-r
                          from-[#005BA9]
                          to-[#0078C1]
                          text-white
                          text-lg
                          font-bold
                          shadow-lg
                          hover:scale-105
                          transition duration-300">

                    ← Kembali

                </a>

            </div>

        </div>

    </div>

</div>


<div id="resetModal"
     class="fixed inset-0
            bg-black/40
            hidden
            items-center
            justify-center
            z-50">

    <div class="bg-white
                rounded-[32px]
                p-10
                w-full
                max-w-xl
                shadow-2xl">

        <h2 class="text-3xl
                   font-black
                   text-[#1E293B]
                   mb-8">

            Reset Password

        </h2>

        <form method="POST"
              action="<?php echo e(route('admin.pengguna.resetpassword', $user->id)); ?>">

            <?php echo csrf_field(); ?>

            
            <div class="mb-6">

                <label class="block
                              font-bold
                              text-[#1E293B]
                              mb-3">

                    Password Baru

                </label>

                <input type="password"
                    name="password"
                    required
                    class="w-full h-16
                           rounded-2xl
                           border border-[#DCE6F0]
                           bg-[#F8FBFF]
                           px-6">

            </div>

            
            <div class="mb-10">

                <label class="block
                              font-bold
                              text-[#1E293B]
                              mb-3">

                    Konfirmasi Password

                </label>

                <input type="password"
                    name="password_confirmation"
                    required
                    class="w-full h-16
                           rounded-2xl
                           border border-[#DCE6F0]
                           bg-[#F8FBFF]
                           px-6">

            </div>

            
            <div class="flex gap-4">

                
                <button type="submit"
                    class="flex-1 h-16
                           rounded-2xl
                           bg-gradient-to-r
                           from-[#EF4444]
                           to-[#DC2626]
                           text-white
                           font-bold
                           text-lg">

                    Simpan Password

                </button>

                
                <button type="button"
                    onclick="closeModal()"
                    class="flex-1 h-16
                           rounded-2xl
                           border border-[#DCE6F0]
                           bg-white
                           font-bold
                           text-lg
                           text-[#1E293B]">

                    Batal

                </button>

            </div>

        </form>

    </div>

</div>


<script>

    function openModal() {

        document
            .getElementById(
                'resetModal'
            )

            .classList.remove(
                'hidden'
            );

        document
            .getElementById(
                'resetModal'
            )

            .classList.add(
                'flex'
            );
    }

    function closeModal() {

        document
            .getElementById(
                'resetModal'
            )

            .classList.remove(
                'flex'
            );

        document
            .getElementById(
                'resetModal'
            )

            .classList.add(
                'hidden'
            );
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/detailpengguna.blade.php ENDPATH**/ ?>