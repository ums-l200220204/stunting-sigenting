

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>
        Laporan Data Pertumbuhan Anak
    </title>

    <style>

        @page {

            size: A4 portrait;

            margin: 35px;

        }

        body {

            font-family: Arial, sans-serif;

            font-size: 11px;

            color: #111827;

            line-height: 1.5;

        }

        /* =========================
           TITLE
        ========================= */

        .laporan-title {

            text-align: center;

            margin-bottom: 30px;

        }

        .laporan-title h3 {

            margin: 0;

            font-size: 18px;

            text-transform: uppercase;

            text-decoration: underline;

            letter-spacing: 1px;

        }

        .laporan-title p {

            margin-top: 6px;

            color: #4B5563;

        }

        /* =========================
           INFO
        ========================= */

        .info {

            margin-bottom: 20px;

        }

        .info table {

            width: 100%;

        }

        .info td {

            padding: 3px 0;

            vertical-align: top;

        }

        /* =========================
           SECTION TITLE
        ========================= */

        .section-title {

            margin-top: 20px;

            margin-bottom: 10px;

            font-size: 13px;

            font-weight: bold;

            text-transform: uppercase;

        }

        /* =========================
           SUMMARY
        ========================= */

        .summary-table {

            width: 100%;

            border-collapse: collapse;

            margin-bottom: 10px;

            table-layout: fixed;

        }

        .summary-table td {

            border: 1px solid #D1D5DB;

            padding: 6px 4px;

            vertical-align: middle;

            text-align: center;

        }

        .summary-label {

            font-size: 9px;

            color: #6B7280;

            margin-bottom: 3px;

        }

        .summary-value {

            font-size: 13px;

            font-weight: bold;

            color: #111827;

        }

        .status-table td {

            padding: 5px 2px;

        }

        /* =========================
           TABLE DATA
        ========================= */

        .data-table {

            width: 100%;

            border-collapse: collapse;

            margin-top: 10px;

        }

        .data-table th {

            background: #E5E7EB;

            border: 1px solid #9CA3AF;

            padding: 8px 5px;

            font-size: 9px;

            text-align: center;

        }

        .data-table td {

            border: 1px solid #D1D5DB;

            padding: 7px 5px;

            font-size: 9px;

            text-align: center;

            word-wrap: break-word;

        }

        .data-table tbody tr:nth-child(even) {

            background: #F9FAFB;

        }

        /* =========================
           FOOTER
        ========================= */

        .footer {

            margin-top: 60px;

            width: 100%;

        }

        .signature {

            width: 240px;

            float: right;

            text-align: center;

        }

        .signature .name {

            margin-top: 70px;

            font-weight: bold;

            text-decoration: underline;

        }

    </style>

</head>

<body>

    
    <div class="laporan-title">

        <h3>

            LAPORAN DATA PERTUMBUHAN ANAK

        </h3>

        <p>

            <?php if($bulan && $tahun): ?>

                Periode
                <?php echo e($namaBulan[$bulan]); ?>

                <?php echo e($tahun); ?>


            <?php elseif($bulan): ?>

                Periode
                <?php echo e($namaBulan[$bulan]); ?>


            <?php elseif($tahun): ?>

                Tahun
                <?php echo e($tahun); ?>


            <?php else: ?>

                Semua Periode

            <?php endif; ?>

        </p>

    </div>

    
    <div class="info">

        <table>

            <tr>

                <td width="170">

                    <strong>
                        Tanggal Cetak
                    </strong>

                </td>

                <td width="10">

                    :

                </td>

                <td>

                    <?php echo e(date('d F Y')); ?>


                </td>

            </tr>

            <tr>

                <td>

                    <strong>
                        Total Data Anak
                    </strong>

                </td>

                <td>

                    :

                </td>

                <td>

                    <?php echo e($totalAnak); ?> Anak

                </td>

            </tr>

        </table>

    </div>

    
    <div class="section-title">

        Ringkasan Statistik

    </div>

    
    <table class="summary-table">

        <tr>

            <td width="50%">

                <div class="summary-label">

                    Anak Laki-Laki

                </div>

                <div class="summary-value">

                    <?php echo e($laki); ?>


                </div>

            </td>

            <td width="50%">

                <div class="summary-label">

                    Anak Perempuan

                </div>

                <div class="summary-value">

                    <?php echo e($perempuan); ?>


                </div>

            </td>

        </tr>

    </table>

    
    <table class="summary-table status-table">

        <tr>

            <td width="25%">

                <div class="summary-label">

                    Normal

                </div>

                <div class="summary-value">

                    <?php echo e($normal); ?>


                </div>

            </td>

            <td width="25%">

                <div class="summary-label">

                    Tinggi

                </div>

                <div class="summary-value">

                    <?php echo e($tinggi); ?>


                </div>

            </td>

            <td width="25%">

                <div class="summary-label">

                    Stunting

                </div>

                <div class="summary-value">

                    <?php echo e($stunting); ?>


                </div>

            </td>

            <td width="25%">

                <div class="summary-label">

                    Stunting Berat

                </div>

                <div class="summary-value">

                    <?php echo e($stuntingBerat); ?>


                </div>

            </td>

        </tr>

    </table>

    
    <div class="section-title">

        Data Anak dan Status Pertumbuhan

    </div>

    <table class="data-table">

        <thead>

            <tr>

                <th width="5%">
                    No
                </th>

                <th width="15%">
                    Nama Anak
                </th>

                <th width="7%">
                    JK
                </th>

                <th width="9%">
                    Usia
                </th>

                <th width="15%">
                    Orang Tua
                </th>

                <th width="9%">
                    BB
                </th>

                <th width="9%">
                    TB
                </th>

                <th width="9%">
                    Z-Score
                </th>

                <th width="11%">
                    Status
                </th>

                <th width="11%">
                    Tanggal
                </th>

            </tr>

        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $anak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>

                <td>

                    <?php echo e($loop->iteration); ?>


                </td>

                <td>

                    <?php echo e($item->nama_anak); ?>


                </td>

                <td>

                    <?php echo e($item->jenis_kelamin); ?>


                </td>

                <td>

                    <?php echo e($item->usia_bulan ?? '-'); ?> Bulan

                </td>

                <td>

                    <?php echo e($item->nama_orangtua); ?>


                </td>

                <td>

                    <?php echo e($item->berat_badan ?? '-'); ?> Kg

                </td>

                <td>

                    <?php echo e($item->tinggi_badan ?? '-'); ?> Cm

                </td>

                <td>

                    <?php echo e($item->z_score ?? '-'); ?>


                </td>

                <td>

                    <?php echo e($item->status_gizi ?? '-'); ?>


                </td>

                <td>

                    <?php if($item->tanggal_pengukuran): ?>

                        <?php echo e(date('d-m-Y', strtotime($item->tanggal_pengukuran))); ?>


                    <?php else: ?>

                        -

                    <?php endif; ?>

                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td colspan="10">

                    Tidak ada data tersedia.

                </td>

            </tr>

            <?php endif; ?>

        </tbody>

    </table>

    
    <div class="footer">

        <div class="signature">

            <p>

                <?php echo e(date('d F Y')); ?>


            </p>

            <p>

                Petugas Posyandu

            </p>

            <div class="name">

                ....................................

            </div>

        </div>

    </div>

</body>

</html><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/admin/laporan-pdf.blade.php ENDPATH**/ ?>