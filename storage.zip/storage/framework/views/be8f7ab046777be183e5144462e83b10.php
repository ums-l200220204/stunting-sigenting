<?php echo e($slot); ?>

<?php /**PATH D:\SKRIPSI\backup\stunting-sigenting\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>