

<?php $__env->startSection('title', 'Data Laporan'); ?>

<?php $__env->startSection('content'); ?>



<div class="min-h-screen pb-12" style="background:#F0F4FA; font-family:'DM Sans',sans-serif;">

    
    <div class="mb-8 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">

        <div>
            <p class="text-xs font-semibold tracking-[0.1em] uppercase mb-2"
               style="color:#005BA9;">
                Kader — Statistik
            </p>
            <h1 class="font-extrabold text-slate-900 leading-tight tracking-tight
                       text-3xl md:text-4xl"
                style="font-family:'Sora',sans-serif;">
                Data Laporan
            </h1>
            <p class="mt-2 text-slate-500 text-base">
                Ringkasan statistik pertumbuhan anak, status gizi, dan perkembangan stunting.
            </p>
        </div>

        
        <div class="flex flex-wrap items-center gap-3">

            
            <select id="filter-bulan"
                    class="bg-white border border-slate-200 rounded-2xl
                           px-4 py-2.5 text-sm text-slate-700
                           focus:outline-none focus:ring-2"
                    style="focus:ring-color:#005BA9;">
                <option value="">Semua Bulan</option>
                <option value="1"  <?php echo e(request('bulan') == '1'  ? 'selected' : ''); ?>>Januari</option>
                <option value="2"  <?php echo e(request('bulan') == '2'  ? 'selected' : ''); ?>>Februari</option>
                <option value="3"  <?php echo e(request('bulan') == '3'  ? 'selected' : ''); ?>>Maret</option>
                <option value="4"  <?php echo e(request('bulan') == '4'  ? 'selected' : ''); ?>>April</option>
                <option value="5"  <?php echo e(request('bulan') == '5'  ? 'selected' : ''); ?>>Mei</option>
                <option value="6"  <?php echo e(request('bulan') == '6'  ? 'selected' : ''); ?>>Juni</option>
                <option value="7"  <?php echo e(request('bulan') == '7'  ? 'selected' : ''); ?>>Juli</option>
                <option value="8"  <?php echo e(request('bulan') == '8'  ? 'selected' : ''); ?>>Agustus</option>
                <option value="9"  <?php echo e(request('bulan') == '9'  ? 'selected' : ''); ?>>September</option>
                <option value="10" <?php echo e(request('bulan') == '10' ? 'selected' : ''); ?>>Oktober</option>
                <option value="11" <?php echo e(request('bulan') == '11' ? 'selected' : ''); ?>>November</option>
                <option value="12" <?php echo e(request('bulan') == '12' ? 'selected' : ''); ?>>Desember</option>
            </select>

            
            <select id="filter-tahun"
                    class="bg-white border border-slate-200 rounded-2xl
                           px-4 py-2.5 text-sm text-slate-700
                           focus:outline-none">
                <option value="">Semua Tahun</option>
                <?php for($i = date('Y'); $i >= 2020; $i--): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e(request('tahun') == $i ? 'selected' : ''); ?>>
                        <?php echo e($i); ?>

                    </option>
                <?php endfor; ?>
            </select>

            
            <a id="btn-cetak-pdf"
               href="<?php echo e(route('kader.laporan.cetak', ['bulan' => request('bulan'), 'tahun' => request('tahun')])); ?>"
               target="_blank"
               class="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl
                      text-white text-sm font-semibold
                      transition-all duration-200 hover:opacity-90 hover:-translate-y-px"
               style="background:#005BA9;">
                <svg class="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none"
                     viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M12 10v6m0 0l-3-3m3 3l3-3M3 17v3a1 1 0 001 1h16a1 1 0 001-1v-3"/>
                </svg>
                Preview Laporan PDF
            </a>

        </div>

    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">

        
        <div class="relative overflow-hidden bg-white rounded-3xl p-7 border border-slate-200"
             style="box-shadow:0 4px 24px -6px rgba(0,91,169,0.08);">
            <div class="absolute -top-6 -right-6 w-32 h-32 rounded-full pointer-events-none"
                 style="background:#005BA9; opacity:.05;"></div>
            <div class="relative z-10">
                <div class="w-12 h-12 rounded-2xl flex items-center justify-center mb-5 text-xl"
                     style="background:#EBF3FF;">
                    👶
                </div>
                <p class="text-xs font-semibold tracking-[0.08em] uppercase text-slate-400 mb-1">
                    Total Anak
                </p>
                <h2 id="text-totalAnak"
                    class="font-extrabold text-slate-900 text-4xl leading-none"
                    style="font-family:'Sora',sans-serif;">
                    <?php echo e($totalAnak); ?>

                </h2>
            </div>
        </div>

        
        <div class="relative overflow-hidden bg-white rounded-3xl p-7 border border-slate-200"
             style="box-shadow:0 4px 24px -6px rgba(0,120,193,0.08);">
            <div class="absolute -top-6 -right-6 w-32 h-32 rounded-full pointer-events-none"
                 style="background:#0078C1; opacity:.05;"></div>
            <div class="relative z-10">
                <div class="w-12 h-12 rounded-2xl flex items-center justify-center mb-5 text-xl"
                     style="background:#E6F4FF;">
                    👦
                </div>
                <p class="text-xs font-semibold tracking-[0.08em] uppercase text-slate-400 mb-1">
                    Anak Laki-Laki
                </p>
                <h2 id="text-laki"
                    class="font-extrabold text-slate-900 text-4xl leading-none"
                    style="font-family:'Sora',sans-serif;">
                    <?php echo e($laki); ?>

                </h2>
            </div>
        </div>

        
        <div class="relative overflow-hidden bg-white rounded-3xl p-7 border border-slate-200"
             style="box-shadow:0 4px 24px -6px rgba(253,75,199,0.08);">
            <div class="absolute -top-6 -right-6 w-32 h-32 rounded-full pointer-events-none"
                 style="background:#FD4BC7; opacity:.05;"></div>
            <div class="relative z-10">
                <div class="w-12 h-12 rounded-2xl flex items-center justify-center mb-5 text-xl"
                     style="background:#FDE8F8;">
                    👧
                </div>
                <p class="text-xs font-semibold tracking-[0.08em] uppercase text-slate-400 mb-1">
                    Anak Perempuan
                </p>
                <h2 id="text-perempuan"
                    class="font-extrabold text-slate-900 text-4xl leading-none"
                    style="font-family:'Sora',sans-serif;">
                    <?php echo e($perempuan); ?>

                </h2>
            </div>
        </div>

    </div>

    
    <div class="grid grid-cols-1 xl:grid-cols-2 gap-5 mb-5">

        
        <div class="bg-white rounded-3xl border border-slate-200 p-7"
             style="box-shadow:0 4px 24px -6px rgba(0,91,169,0.06);">

            <div class="flex items-start justify-between mb-6">
                <div>
                    <h2 class="font-bold text-slate-900 text-lg tracking-tight"
                        style="font-family:'Sora',sans-serif;">
                        Status Gizi Anak
                    </h2>
                    <p class="mt-0.5 text-xs text-slate-400">
                        Berdasarkan data pemeriksaan terbaru.
                    </p>
                </div>
                
                <div class="hidden md:flex flex-wrap gap-1.5 justify-end max-w-[220px]">
                    <?php $__currentLoopData = [
                        ['Belum Dicek','#94A3B8'],
                        ['Stunting Berat','#FF4D4F'],
                        ['Stunting','#FFB200'],
                        ['Normal','#00C951'],
                        ['Tinggi','#8B5CF6'],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full"
                          style="background:<?php echo e($color); ?>18; color:<?php echo e($color); ?>;">
                        <span class="w-1.5 h-1.5 rounded-full inline-block" style="background:<?php echo e($color); ?>;"></span>
                        <?php echo e($label); ?>

                    </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <canvas id="statusChart" height="80"></canvas>

        </div>

        
        <div class="bg-white rounded-3xl border border-slate-200 p-7"
             style="box-shadow:0 4px 24px -6px rgba(0,91,169,0.06);">

            <div class="mb-6">
                <h2 class="font-bold text-slate-900 text-lg tracking-tight"
                    style="font-family:'Sora',sans-serif;">
                    Distribusi Jenis Kelamin
                </h2>
                <p class="mt-0.5 text-xs text-slate-400">
                    Perbandingan jumlah anak.
                </p>
            </div>

            
            <div class="flex items-center gap-8">
                <div class="flex-shrink-0" style="width:180px;">
                    <canvas id="genderChart"></canvas>
                </div>
                <div class="flex flex-col gap-4">
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="w-3 h-3 rounded-full inline-block" style="background:#0078C1;"></span>
                            <span class="text-xs font-medium text-slate-500">Laki-Laki</span>
                        </div>
                        <p id="legend-laki"
                           class="font-extrabold text-2xl text-slate-900"
                           style="font-family:'Sora',sans-serif;">
                            <?php echo e($laki); ?>

                        </p>
                    </div>
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="w-3 h-3 rounded-full inline-block" style="background:#FD4BC7;"></span>
                            <span class="text-xs font-medium text-slate-500">Perempuan</span>
                        </div>
                        <p id="legend-perempuan"
                           class="font-extrabold text-2xl text-slate-900"
                           style="font-family:'Sora',sans-serif;">
                            <?php echo e($perempuan); ?>

                        </p>
                    </div>
                </div>
            </div>

        </div>

    </div>

    
    <div class="bg-white rounded-3xl border border-slate-200 p-7"
         style="box-shadow:0 4px 24px -6px rgba(0,91,169,0.06);">

        <div class="flex items-start justify-between mb-6">
            <div>
                <h2 class="font-bold text-slate-900 text-lg tracking-tight"
                    style="font-family:'Sora',sans-serif;">
                    Kelompok Usia Anak
                </h2>
                <p class="mt-0.5 text-xs text-slate-400">
                    Distribusi usia anak berdasarkan data pertumbuhan terbaru (bulan).
                </p>
            </div>
            <span class="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-full"
                  style="background:#EBF3FF; color:#005BA9;">
                <span class="w-2 h-2 rounded-full inline-block" style="background:#005BA9;"></span>
                Jumlah Anak
            </span>
        </div>

        <canvas id="usiaChart" height="90"></canvas>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0"></script>

<script>
Chart.register(ChartDataLabels);

// ── Shared datalabels config ──────────────────────────
const dlBase = {
    color: '#ffffff',
    font: { weight: 'bold', size: 13 },
    formatter: v => v > 0 ? v : ''
};

// ── STATUS GIZI ───────────────────────────────────────
let statusChartInstance = new Chart(document.getElementById('statusChart'), {
    type: 'bar',
    data: {
        labels: ['Belum Dicek', 'Stunting Berat', 'Stunting', 'Normal', 'Tinggi'],
        datasets: [{
            data: [<?php echo e($belumDicek); ?>, <?php echo e($stuntingBerat); ?>, <?php echo e($stunting); ?>, <?php echo e($normal); ?>, <?php echo e($tinggi); ?>],
            backgroundColor: ['#94A3B8','#FF4D4F','#FFB200','#00C951','#8B5CF6'],
            borderRadius: 10,
            borderSkipped: false,
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            datalabels: { ...dlBase, anchor: 'center', align: 'center' }
        },
        layout: { padding: { top: 16 } },
        scales: {
            x: { grid: { display: false }, border: { display: false } },
            y: {
                beginAtZero: true,
                ticks: { stepSize: 1, precision: 0, color: '#94A3B8', font: { size: 11 } },
                grid: { color: '#F1F5F9' },
                border: { display: false }
            }
        }
    }
});

// ── GENDER ────────────────────────────────────────────
let genderChartInstance = new Chart(document.getElementById('genderChart'), {
    type: 'doughnut',
    data: {
        labels: ['Laki-Laki', 'Perempuan'],
        datasets: [{
            data: [<?php echo e($laki); ?>, <?php echo e($perempuan); ?>],
            backgroundColor: ['#0078C1','#FD4BC7'],
            borderWidth: 0,
            hoverOffset: 6
        }]
    },
    options: {
        responsive: true,
        cutout: '75%',
        plugins: {
            legend: { display: false },
            datalabels: {
                ...dlBase,
                color: '#fff',
                font: { weight: 'bold', size: 12 },
                formatter: v => v > 0 ? v : ''
            }
        }
    }
});

    // =========================
    // USIA DETAIL
    // =========================
    let usiaChartInstance = new Chart(
        document.getElementById('usiaChart'),
        {
            type: 'line',
            data: {
                labels: ['0-6', '7-12', '13-18', '19-24', '25-36', '37-48', '49-60'],
                datasets: [{
                    label: 'Jumlah Anak',
                    data: [
                        <?php echo e($usia0_6 ?? 0); ?>, <?php echo e($usia7_12 ?? 0); ?>, <?php echo e($usia13_18 ?? 0); ?>,
                        <?php echo e($usia19_24 ?? 0); ?>, <?php echo e($usia25_36 ?? 0); ?>, <?php echo e($usia37_48 ?? 0); ?>,
                        <?php echo e($usia49_60 ?? 0); ?>

                    ],
                    borderColor: '#005BA9',
                    backgroundColor: 'rgba(0,91,169,0.08)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 4,
                    pointRadius: 5
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    datalabels: {
                        color: '#005BA9', // Warna biru menyesuaikan garis
                        font: { weight: 'bold', size: 12 },
                        anchor: 'end', // Posisikan di atas titik kordinat
                        align: 'top',
                        offset: 4,
                        formatter: function(value) {
                            return value > 0 ? value : '';
                        }
                    }
                },
                layout: { padding: { top: 20 } },
                scales: { y: { beginAtZero: true } }
            }
        }
    );

// ── FILTER AJAX ───────────────────────────────────────
const filterBulan  = document.getElementById('filter-bulan');
const filterTahun  = document.getElementById('filter-tahun');
const btnCetakPdf  = document.getElementById('btn-cetak-pdf');

function updateDataLaporan() {
    const bulan = filterBulan.value;
    const tahun = filterTahun.value;

    btnCetakPdf.href = `<?php echo e(route('kader.laporan.cetak')); ?>?bulan=${bulan}&tahun=${tahun}`;

    const url = new URL(window.location.href);
    url.searchParams.set('bulan', bulan);
    url.searchParams.set('tahun', tahun);

    fetch(url, {
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' }
    })
    .then(r => r.json())
    .then(data => {
        document.getElementById('text-totalAnak').innerText  = data.totalAnak;
        document.getElementById('text-laki').innerText       = data.laki;
        document.getElementById('text-perempuan').innerText  = data.perempuan;
        document.getElementById('legend-laki').innerText     = data.laki;
        document.getElementById('legend-perempuan').innerText = data.perempuan;

        statusChartInstance.data.datasets[0].data = [
            data.belumDicek, data.stuntingBerat, data.stunting, data.normal, data.tinggi
        ];
        statusChartInstance.update();

        genderChartInstance.data.datasets[0].data = [data.laki, data.perempuan];
        genderChartInstance.update();

        usiaChartInstance.data.datasets[0].data = [
            data.usia0_6, data.usia7_12, data.usia13_18, data.usia19_24,
            data.usia25_36, data.usia37_48, data.usia49_60
        ];
        usiaChartInstance.update();
    })
    .catch(err => console.error('Gagal mengambil data:', err));
}

filterBulan.addEventListener('change', updateDataLaporan);
filterTahun.addEventListener('change', updateDataLaporan);

window.addEventListener('pageshow', e => { if (e.persisted) window.location.reload(); });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\SKRIPSI\stunting\stunting\resources\views/kader/laporan.blade.php ENDPATH**/ ?>